package org.ensea.student.core.displayable.ui;

import org.ensea.student.core.displayable.Displayable;
import org.ensea.student.core.inventory.Item;

public class ItemButton implements Displayable, Selectable {
    public Item item;
    public boolean isSelected;

    public ItemButton(Item item){
        this.item = item;
    }

    @Override
    public void draw() {

    }

    @Override
    public void onSelect() {
        isSelected = true;
        //highlight
        //display description
        //display features
    }
}
