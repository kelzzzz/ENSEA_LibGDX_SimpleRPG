package org.ensea.student.core.inventory;

public class JSONToItem {

}
