package org.ensea.student.core.inventory;


import org.ensea.student.core.displayable.SpriteWrapper;

public interface Item {
    public float getItemWeight();
    public float getItemValue();
    public String getItemLabel();
    public String getItemDescription();
    public SpriteWrapper getItemSprite();
    public String getItemType();
}
